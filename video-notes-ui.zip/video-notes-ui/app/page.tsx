export default function Home() {
  return (
    <main className="p-6">
      <h1 className="text-3xl font-bold text-center mb-6">Video Notes UI</h1>
      <p className="text-center text-gray-500">Subí un video para empezar</p>
    </main>
  );
}
